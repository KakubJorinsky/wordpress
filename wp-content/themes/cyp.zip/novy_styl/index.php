<?php get_header(); ?>

<main>
    <?php
        the_content();
    ?>
</main>